// pages/api/ai.js
// Vercel Serverless Function — proxy for Gemini API
// The API key is in the frontend (App.jsx) — this route is kept as backup

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { prompt, system } = req.body;
  if (!prompt) return res.status(400).json({ error: "prompt is required" });

  const GEMINI_KEY = process.env.GEMINI_API_KEY || "AIzaSyBI_JiTJjBA25VQm6QddpwG3vrxuzwFTwQ";
  const fullPrompt = system ? `${system}\n\n${prompt}` : prompt;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: fullPrompt }] }],
          generationConfig: { maxOutputTokens: 1000, temperature: 0.85 },
        }),
      }
    );
    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ error: err.error?.message || "Gemini error" });
    }
    const data = await response.json();
    const result = data.candidates?.[0]?.content?.parts?.[0]?.text || "No response";
    return res.status(200).json({ result });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
